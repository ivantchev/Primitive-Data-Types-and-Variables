﻿ using System;

    class EmployeeData
    {
        static void Main()
        {
            string firstName = "Pesho";
            string lastName = "TuranagaSan";
            int employeeAge= 24;
            char employeeGender='m';
            long employeeIdNumber= 8306112507;
            int employeeNumber = 27560000;
            Console.WriteLine("First Name: {0}", firstName);
            Console.WriteLine("Last Name: {0}", lastName);
            Console.WriteLine("Employee Age: {0}",employeeAge);
            Console.WriteLine("Employee Gender: {0}", employeeGender);
            Console.WriteLine("Employee ID Number: {0}", employeeIdNumber);
            Console.WriteLine("Employee Number: {0}", employeeNumber);
        }
    }

