﻿using System;

    class BankAccountData
    {
        static void Main()
        {
            string firstName = "Pesho";
            string middleName = "AllMighty";
            string lastName = "TuranagaSan";
            decimal accBalance = 134.255m;
            string bankName = "HSBC";
            string iBan = "GB15MIDL40051512345678";
            ulong cardOne = 560221560265;
            ulong cardTwo = 857221560255;
            ulong cardThree = 266821568225;
            
        }
    }

