﻿using System;

    class DeclareVariables
    {
        static void Main()
        {
            sbyte numberOne = -115;
            byte numberTwo = 97;
            ushort numberThree = 52130;
            short numberFour = -10000;
            int numberFive = 4825932;
            Console.WriteLine("{0} {1} {2} {3} {4} ", numberOne,numberTwo,numberThree,numberFour,numberFive);
        }
    }

