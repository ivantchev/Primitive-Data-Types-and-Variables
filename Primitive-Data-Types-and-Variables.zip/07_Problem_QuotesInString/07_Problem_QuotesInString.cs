﻿using System;

    class QuotesInString
    {
        static void Main()
        {
            string firstQuotes= "The use of quotations causes difficulties";
            string secondQuotes= @"The use of quotations causes difficulties";
            Console.WriteLine(firstQuotes);
            Console.WriteLine(secondQuotes);

        }
    }

