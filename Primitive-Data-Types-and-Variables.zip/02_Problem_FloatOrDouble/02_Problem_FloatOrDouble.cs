﻿using System;

    class FloatOrDouble
    {
        static void Main()
        {
            float numberOne = 12.345f;
            float numberTwo = 3456.091f;
            double numberThree = 34.56783923;
            double numberFour = 8923.1234857;

            Console.WriteLine("{0} {1} {2} {3}", numberOne, numberTwo, numberThree, numberFour);


        }
    }

