﻿using System;

    class IsoscelesTriangle
    {
        static void Main()
        {
            char a='\u00A9';
            Console.WriteLine(
                 @"
                 {0}

                {0} {0}

               {0}  {0}

               {0}{0}{0}{0}", a);
           
        }
    }

