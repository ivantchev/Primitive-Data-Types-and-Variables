﻿using System;

    class VariableInHexadecimalFormat
   {
        static void Main()
        {
            int value = 0xFE;
            Console.WriteLine("{0}", value);
        }
    }

