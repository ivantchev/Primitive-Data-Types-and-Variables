﻿using System;

    class BooleanVariable
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine("Am I a female? --> " + isFemale);
        }
    }

